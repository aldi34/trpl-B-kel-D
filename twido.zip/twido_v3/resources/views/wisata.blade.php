<html>
    <head>
        <title></title>
    </head>
    <body>
        <select id="kota" name="kota">
            <option value="">Pilih Kota</option>
            @foreach($kotanya as $k)
        <option value="{{$k->id}}" >{{$k->nama_kota}}</option>
            @endforeach
        </select>

         <select id="wisata" name="wisata">
            <option value="">Pilih Wisata</option>
        </select>
    </body>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script type="text/javascript">
        $('#kota').on('change', function(e){
            console.log(e);
            var id_kota = e.target.value;
            $.get('/json-wisata?kota_id=' + id_kota, function(data){
                $('#wisata').empty();
                $('#wisata').append('<option value="0" selected="true" disabled="true">Pilih WIsata Anda</option>')
                $.each(data, function(index, wisataObj){
                    $('#wisata').append('<option value="'+wisataObj.id +'">'+ wisataObj.nama_wisata +'</option>')
                })
            });
        });
    </script>
</html>