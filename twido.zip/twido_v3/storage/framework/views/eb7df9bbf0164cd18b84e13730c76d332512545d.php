<!DOCTYPE html>
<html lang="en">
	
<head>
	<title>TWIDO - Trip Wisata Indonesia</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="<?php echo e(asset('assets/https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900')); ?>" rel="stylesheet">

	<link rel="stylesheet" href="<?php echo e(asset('assets/css/open-iconic-bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('assets/css/aos.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('assets/css/ionicons.min.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datepicker.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.timepicker.css')); ?>">


	<link rel="stylesheet" href="<?php echo e(asset('assets/css/flaticon.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/icomoon.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
</head>

<body>
	<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
		<div class="container">
			<a class="navbar-brand" href="beranda">TWIDO<span>Trip Wisata Indonesia</span></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav"
				aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="oi oi-menu"></span> Menu
			</button>

			<div class="collapse navbar-collapse" id="ftco-nav">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item"><a href="beranda" class="nav-link">Beranda</a></li>
					<li class="nav-item active"><a href="rekom" class="nav-link">Rekomendasi</a></li>
					<li class="nav-item"><a href="#" class="nav-link">Daftar Mitra</a></li>
					<li class="nav-item cta"><a href="#" class="nav-link">Beli Paket</a></li>

				</ul>
			</div>
		</div>
	</nav>
	<!-- END nav -->

	

	

	<section class="ftco-section ftco-no-pb ftco-no-pt" style="margin-top:0px; margin-bottom:20px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12 mb-5">
					<div class="search-wrap-1 search-wrap-notop ftco-animate p-4" style="height:100px;">
				</div>
			</div>
		</div>
	</section>


	<section class="ftco-section ftco-no-pt">
		<div class="container">
			<div class="row justify-content-center pb-4">
				<div class="col-md-12 heading-section text-center ftco-animate">
					<h2 class="mb-4">Rekomendasi Wisata</h2>
				</div>
			</div>
			<div class="row">

				<?php $__currentLoopData = $hasilcari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-4 ftco-animate">
					<div class="project-wrap">
						<!-- <a href="#" class="img" style="background-image: url(<?php echo e($hc->gambar); ?>);"></a> -->

							<img src="<?php echo e($hc->getAvatar()); ?>" class="img">						
							<div class="text p-4">
							<span class="price"><?php echo e($hc->harga); ?>/Orang</span>
							<span class="days"><?php echo e($hc->nama_destinasi); ?></span>
							<h3><a href="#"><?php echo e($hc->nama_destinasi); ?></a></h3>
							<p class="location"><span class="ion-ios-map"></span> <?php echo e($kotaPencarian->nama_kota); ?>, <?php echo e($provinsiPencarian->nama_provinsi); ?></p>
							<ul>
								<li><span class="flaticon-shower"></span>2</li>
								<li><span class="flaticon-king-size"></span>3</li>
								<li><span class="flaticon-mountains"></span><?php echo e($hc->tipe_destinasi); ?></li>
							</ul>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




			</div>
			<div class="row mt-5">
				<div class="col text-center">
					<div class="block-27">
						<ul>
							<li><a href="#">&lt;</a></li>
							<li class="active"><span>1</span></li>
							<li><a href="#">2</a></li>
							<li><a href="#">3</a></li>
							<li><a href="#">4</a></li>
							<li><a href="#">5</a></li>
							<li><a href="#">&gt;</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>

	<footer class="ftco-footer bg-bottom" style="background-image: url(/assets/images/footer-bg.jpg);">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Twido</h2>
              <p>Trip Wisata Indonesi yang menawarkan sejumlah kenyamanan bagi para traveller untuk menikmati liburannya.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Informasi</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">Pertanyaan Online</a></li>
                <li><a href="#" class="py-2 d-block">Pertanyaan Umum</a></li>
                <li><a href="#" class="py-2 d-block">Kondisi Pemesanan</a></li>
                <li><a href="#" class="py-2 d-block">Kebijakan dan Privasi</a></li>
                <li><a href="#" class="py-2 d-block">Kebijakan Pengembalian</a></li>
                <li><a href="#" class="py-2 d-block">Hubungi Kami</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Pengalaman</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">Petualangan</a></li>
                <li><a href="#" class="py-2 d-block">Hotel dan Restoran</a></li>
                <li><a href="#" class="py-2 d-block">Pantai</a></li>
                <li><a href="#" class="py-2 d-block">Gunung</a></li>
                <li><a href="#" class="py-2 d-block">Berkemah</a></li>
                <li><a href="#" class="py-2 d-block">Pesta</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Ajukan Pertanyaan ?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">Universitas Jember, Jl. Kalimantan No.37, Krajan Timur, Sumbersari, Jember</span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">(0331) 330224</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">unej.ac.id</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

			<p>Copyright &copy;<script>document.write(new Date().getFullYear());
			</script> All rights reserved | Trip Wisata Indonesia
			<i class="icon-heart color-danger" aria-hidden="true"></i> by 
			<a href="https://colorlib.com" target="_blank">TRPL B Kel.4</a>
  			</p>
            
           </div>
        </div>
      </div>
    </footer>



	<!-- loader -->
	<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
			<circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
			<circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
				stroke="#F96D00" /></svg></div>


	<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.easing.1.3.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.waypoints.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.stellar.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/aos.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.animateNumber.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/bootstrap-datepicker.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/scrollax.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false')); ?>">
	</script>
	<script src="<?php echo e(asset('assets/js/google-map.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

</body>


</html><?php /**PATH C:\xampp\htdocs\twido_v3\resources\views/hasilcari.blade.php ENDPATH**/ ?>