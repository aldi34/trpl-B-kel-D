<html>
    <head>
        <title></title>
    </head>
    <body>
        <select id="kota" name="kota">
            <option value="">Pilih Kota</option>
            <?php $__currentLoopData = $kotanya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($k->id); ?>" ><?php echo e($k->nama_kota); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

         <select id="wisata" name="wisata">
            <option value="">Pilih Wisata</option>
        </select>
    </body>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script type="text/javascript">
        $('#kota').on('change', function(e){
            console.log(e);
            var id_kota = e.target.value;
            $.get('/json-wisata?kota_id=' + id_kota, function(data){
                $('#wisata').empty();
                $('#wisata').append('<option value="0" selected="true" disabled="true">Pilih WIsata Anda</option>')
                $.each(data, function(index, wisataObj){
                    $('#wisata').append('<option value="'+wisataObj.id +'">'+ wisataObj.nama_wisata +'</option>')
                })
            });
        });
    </script>
</html><?php /**PATH C:\xampp\htdocs\twido_v3\resources\views/wisata.blade.php ENDPATH**/ ?>