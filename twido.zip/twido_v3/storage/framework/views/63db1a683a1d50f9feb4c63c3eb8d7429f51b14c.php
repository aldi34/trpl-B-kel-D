<!DOCTYPE html>
<html lang="en">
	


    

<head>
	<title>TWIDO - Trip Wisata Indonesia</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="<?php echo e(asset('assets/https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900')); ?>" rel="stylesheet">

	<link rel="stylesheet" href="<?php echo e(asset('assets/css/open-iconic-bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('assets/css/aos.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('assets/css/ionicons.min.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap-datepicker.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/jquery.timepicker.css')); ?>">


	<link rel="stylesheet" href="<?php echo e(asset('assets/css/flaticon.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/icomoon.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
</head>

<body>
	<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
		<div class="container">
			<a class="navbar-brand" href="beranda">TWIDO<span>Trip Wisata Indonesia</span></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav"
				aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="oi oi-menu"></span> Menu
			</button>

			<div class="collapse navbar-collapse" id="ftco-nav">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item"><a href="beranda" class="nav-link">Beranda</a></li>
					<li class="nav-item active"><a href="rekom" class="nav-link">Rekomendasi</a></li>
					<li class="nav-item"><a href="#" class="nav-link">Daftar Mitra</a></li>
					<li class="nav-item cta"><a href="#" class="nav-link">Beli Paket</a></li>

				</ul>
			</div>
		</div>
	</nav>
	<!-- END nav -->

	<section class="hero-wrap hero-wrap-2 js-fullheight" style="background-image: url(/assets/images/foto2.jpg);"
		data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="container">
			<div class="row no-gutters slider-text js-fullheight align-items-end justify-content-center">
				<div class="col-md-9 ftco-animate pb-5 text-center">
					<h1 class="mb-3 bread">Rekomendasi Wisata</h1>
					<p class="breadcrumbs"><span class="mr-2"><a href="beranda">Home <i
									class="ion-ios-arrow-forward"></i></a></span> <span>Rekomendasi <i
								class="ion-ios-arrow-forward"></i></span></p>
				</div>
			</div>
		</div>
	</section>

	

	<section class="ftco-section ftco-no-pb ftco-no-pt" style="margin-top:30px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12 mb-5">
					<div class="search-wrap-1 search-wrap-notop ftco-animate p-4">
					<form action="<?php echo e(url('/cari-rekom')); ?>" class="search-property-1" method="POST">
						<?php echo e(csrf_field()); ?>

							<div class="row">
								<div class="col-lg align-items-end">
									<div class="form-group">
										<label for="#">Provinsi</label>
										<div class="form-field">
											<div class="select-wrap">
												<div class="icon"><span class="ion-ios-arrow-down"></span></div>
												<select id="provinsi" name="provinsi" class="form-control">
													<option value="">Pilih Provinsi</option>
													<?php $__currentLoopData = $provinsinya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<option value="<?php echo e($p->id); ?>" ><?php echo e($p->nama_provinsi); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
											</div>
										</div>
									</div>
								</div>
								<div class="col-lg align-items-end">
									<div class="form-group">
										<label for="#">Kabupaten</label>
										<div class="form-field">
											<div class="select-wrap">
												<div class="icon"><span class="ion-ios-arrow-down"></span></div>
												<select id="kota" name="kota" class="form-control">
													<option value="">Pilih Kota</option>
												</select>
											</div>
										</div>
									</div>
								</div>
								
								<div class="col-lg align-items-end">
									<div class="form-group">
										<label for="#">Destinasi</label>
										<div class="form-field">
											<div class="select-wrap">
												<div class="icon"><span class="ion-ios-arrow-down"></span></div>
												<select id="jenis" name="jenis" class="form-control">
													<option value="0" selected="true" disabled="true">Pilih wisata</option>
													<option value="Pantai">Pantai</option>
													<option value="Gunung">Gunung</option>
													<option value="Taman">Taman</option>
													<option value="Air Terjun">Air Terjun</option>
												</select>
											</div>
										</div>
									</div>
								</div>
								<div class="col-lg align-self-end">
									<div class="form-group">
										<div class="form-field">
											<input type="submit" value="Cari" class="form-control btn btn-primary">
										</div>
									</div>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>


	<section class="ftco-section ftco-no-pt">
		<div class="container">
			<div class="row justify-content-center pb-4">
				<div class="col-md-12 heading-section text-center ftco-animate">
					<h2 class="mb-4">Rekomendasi Wisata</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-4 ftco-animate">
					<div class="project-wrap">
						<a href="#" class="img" style="background-image: url(/assets/images/ijen.jpg);"></a>
						<div class="text p-4">
							<span class="price">Rp.150.000/orang</span>
							<span class="days">Wisata Indonesia</span>
							<h3><a href="#">Kawah Ijen</a></h3>
							<p class="location"><span class="ion-ios-map"></span> Bondowoso, Jawa Timur</p>
							<ul>
								<li><span class="flaticon-shower"></span>2</li>
								<li><span class="flaticon-king-size"></span>3</li>
								<li><span class="flaticon-mountains"></span>Gunung</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-4 ftco-animate">
					<div class="project-wrap">
						<a href="#" class="img" style="background-image: url(/assets/images/papuma.jpg);"></a>
						<div class="text p-4">
							<span class="price">Rp.30.000/orang</span>
							<span class="days">Wisata Indonesia</span>
							<h3><a href="#">Pantai Papuma</a></h3>
							<p class="location"><span class="ion-ios-map"></span> Jember, Jawa Timur</p>
							<ul>
								<li><span class="flaticon-shower"></span>2</li>
								<li><span class="flaticon-king-size"></span>3</li>
								<li><span class="flaticon-sun-umbrella"></span>Pantai</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-4 ftco-animate">
					<div class="project-wrap">
						<a href="#" class="img" style="background-image: url(/assets/images/love.jpg);"></a>
						<div class="text p-4">
							<span class="price">Rp.7.500/orang</span>
							<span class="days">Wisata Indonesia</span>
							<h3><a href="#">Teluk Love</a></h3>
							<p class="location"><span class="ion-ios-map"></span> Jember, Jawa Timur</p>
							<ul>
								<li><span class="flaticon-shower"></span>2</li>
								<li><span class="flaticon-king-size"></span>3</li>
								<li><span class="flaticon-sun-umbrella"></span>Pantai</li>
							</ul>
						</div>
					</div>
				</div>

				<!-- <div class="col-md-4 ftco-animate">
        		<div class="project-wrap">
        			<a href="#" class="img" style="background-image: url(images/destination-4.jpg);"></a>
        			<div class="text p-4">
        				<span class="price">$300/person</span>
        				<span class="days">8 Days Tour</span>
        				<h3><a href="#">Bali, Indonesia</a></h3>
        				<p class="location"><span class="ion-ios-map"></span> Bali, Indonesia</p>
        				<ul>
        					<li><span class="flaticon-shower"></span>2</li>
        					<li><span class="flaticon-king-size"></span>3</li>
        					<li><span class="flaticon-sun-umbrella"></span>Near Beach</li>
        				</ul>
        			</div>
        		</div>
        	</div>
        	<div class="col-md-4 ftco-animate">
        		<div class="project-wrap">
        			<a href="#" class="img" style="background-image: url(images/destination-5.jpg);"></a>
        			<div class="text p-4">
        				<span class="price">$300/person</span>
        				<span class="days">10 Days Tour</span>
        				<h3><a href="#">Bali, Indonesia</a></h3>
        				<p class="location"><span class="ion-ios-map"></span> Bali, Indonesia</p>
        				<ul>
        					<li><span class="flaticon-shower"></span>2</li>
        					<li><span class="flaticon-king-size"></span>3</li>
        					<li><span class="flaticon-sun-umbrella"></span>Near Beach</li>
        				</ul>
        			</div>
        		</div>
        	</div>
        	<div class="col-md-4 ftco-animate">
        		<div class="project-wrap">
        			<a href="#" class="img" style="background-image: url(images/destination-6.jpg);"></a>
        			<div class="text p-4">
        				<span class="price">$300/person</span>
        				<span class="days">7 Days Tour</span>
        				<h3><a href="#">Bali, Indonesia</a></h3>
        				<p class="location"><span class="ion-ios-map"></span> Bali, Indonesia</p>
        				<ul>
        					<li><span class="flaticon-shower"></span>2</li>
        					<li><span class="flaticon-king-size"></span>3</li>
        					<li><span class="flaticon-sun-umbrella"></span>Near Beach</li>
        				</ul>
        			</div>
        		</div>
        	</div>

        	<div class="col-md-4 ftco-animate">
        		<div class="project-wrap">
        			<a href="#" class="img" style="background-image: url(images/destination-7.jpg);"></a>
        			<div class="text p-4">
        				<span class="price">$300/person</span>
        				<span class="days">8 Days Tour</span>
        				<h3><a href="#">Bali, Indonesia</a></h3>
        				<p class="location"><span class="ion-ios-map"></span> Bali, Indonesia</p>
        				<ul>
        					<li><span class="flaticon-shower"></span>2</li>
        					<li><span class="flaticon-king-size"></span>3</li>
        					<li><span class="flaticon-mountains"></span>Near Mountain</li>
        				</ul>
        			</div>
        		</div>
        	</div>
        	<div class="col-md-4 ftco-animate">
        		<div class="project-wrap">
        			<a href="#" class="img" style="background-image: url(images/destination-8.jpg);"></a>
        			<div class="text p-4">
        				<span class="price">$300/person</span>
        				<span class="days">10 Days Tour</span>
        				<h3><a href="#">Bali, Indonesia</a></h3>
        				<p class="location"><span class="ion-ios-map"></span> Bali, Indonesia</p>
        				<ul>
        					<li><span class="flaticon-shower"></span>2</li>
        					<li><span class="flaticon-king-size"></span>3</li>
        					<li><span class="flaticon-sun-umbrella"></span>Near Beach</li>
        				</ul>
        			</div>
        		</div>
        	</div>
        	<div class="col-md-4 ftco-animate">
        		<div class="project-wrap">
        			<a href="#" class="img" style="background-image: url(images/destination-9.jpg);"></a>
        			<div class="text p-4">
        				<span class="price">$300/person</span>
        				<span class="days">7 Days Tour</span>
        				<h3><a href="#">Bali, Indonesia</a></h3>
        				<p class="location"><span class="ion-ios-map"></span> Bali, Indonesia</p>
        				<ul>
        					<li><span class="flaticon-shower"></span>2</li>
        					<li><span class="flaticon-king-size"></span>3</li>
        					<li><span class="flaticon-sun-umbrella"></span>Near Beach</li>
        				</ul>
        			</div>
        		</div>
        	</div> -->

				<div class="col-md-4 ftco-animate">
					<div class="project-wrap">
						<a href="#" class="img" style="background-image: url(/assets/images/batur.jpg);"></a>
						<div class="text p-4">
							<span class="price">Rp.15.000/orang</span>
							<span class="days">Wisata Indonesia</span>
							<h3><a href="#">Gunung Batur</a></h3>
							<p class="location"><span class="ion-ios-map"></span> Kintamani, Bali</p>
							<ul>
								<li><span class="flaticon-shower"></span>2</li>
								<li><span class="flaticon-king-size"></span>3</li>
								<li><span class="flaticon-mountains"></span>Gunung</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-4 ftco-animate">
					<div class="project-wrap">
						<a href="#" class="img" style="background-image: url(/assets/images/tanahlot.jpg);"></a>
						<div class="text p-4">
							<span class="price">Rp.20.000/orang</span>
							<span class="days">Wisata Indonesia</span>
							<h3><a href="#">Tanah Lot</a></h3>
							<p class="location"><span class="ion-ios-map"></span> Tabanan, Bali</p>
							<ul>
								<li><span class="flaticon-shower"></span>2</li>
								<li><span class="flaticon-king-size"></span>3</li>
								<li><span class="flaticon-sun-umbrella"></span>Pantai</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-md-4 ftco-animate">
					<div class="project-wrap">
						<a href="#" class="img" style="background-image: url(/assets/images/bromo.jpg);"></a>
						<div class="text p-4">
							<span class="price">Rp.34.000/orang</span>
							<span class="days">Wisata Indonesia</span>
							<h3><a href="#">Gunung Bromo</a></h3>
							<p class="location"><span class="ion-ios-map"></span> Probolinggo, Jawa timur</p>
							<ul>
								<li><span class="flaticon-shower"></span>2</li>
								<li><span class="flaticon-king-size"></span>3</li>
								<li><span class="flaticon-mountains"></span>Gunung</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="row mt-5">
				<div class="col text-center">
					<div class="block-27">
						<ul>
							<li><a href="#">&lt;</a></li>
							<li class="active"><span>1</span></li>
							<li><a href="#">2</a></li>
							<li><a href="#">3</a></li>
							<li><a href="#">4</a></li>
							<li><a href="#">5</a></li>
							<li><a href="#">&gt;</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</section>

	<footer class="ftco-footer bg-bottom" style="background-image: url(/assets/images/footer-bg.jpg);">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Twido</h2>
              <p>Trip Wisata Indonesi yang menawarkan sejumlah kenyamanan bagi para traveller untuk menikmati liburannya.</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Informasi</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">Pertanyaan Online</a></li>
                <li><a href="#" class="py-2 d-block">Pertanyaan Umum</a></li>
                <li><a href="#" class="py-2 d-block">Kondisi Pemesanan</a></li>
                <li><a href="#" class="py-2 d-block">Kebijakan dan Privasi</a></li>
                <li><a href="#" class="py-2 d-block">Kebijakan Pengembalian</a></li>
                <li><a href="#" class="py-2 d-block">Hubungi Kami</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Pengalaman</h2>
              <ul class="list-unstyled">
                <li><a href="#" class="py-2 d-block">Petualangan</a></li>
                <li><a href="#" class="py-2 d-block">Hotel dan Restoran</a></li>
                <li><a href="#" class="py-2 d-block">Pantai</a></li>
                <li><a href="#" class="py-2 d-block">Gunung</a></li>
                <li><a href="#" class="py-2 d-block">Berkemah</a></li>
                <li><a href="#" class="py-2 d-block">Pesta</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Ajukan Pertanyaan ?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">Universitas Jember, Jl. Kalimantan No.37, Krajan Timur, Sumbersari, Jember</span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">(0331) 330224</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">unej.ac.id</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

			<p>Copyright &copy;<script>document.write(new Date().getFullYear());
			</script> All rights reserved | Trip Wisata Indonesia
			<i class="icon-heart color-danger" aria-hidden="true"></i> by 
			<a href="https://colorlib.com" target="_blank">TRPL B Kel.4</a>
  			</p>
            
           </div>
        </div>
      </div>
    </footer>



	<!-- loader -->
	<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px">
			<circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee" />
			<circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10"
				stroke="#F96D00" /></svg></div>


	<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery-migrate-3.0.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.easing.1.3.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.waypoints.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.stellar.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/aos.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/jquery.animateNumber.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/bootstrap-datepicker.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/scrollax.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false')); ?>">
	</script>
	<script src="<?php echo e(asset('assets/js/google-map.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

</body>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script type="text/javascript">
		$('#provinsi').on('change', function(e){
            console.log(e);
            var id_provinsi = e.target.value;
            $.get('/json-kota?provinsi_id=' + id_provinsi, function(data){
                $('#kota').empty();
                $('#kota').append('<option value="0" selected="true" disabled="true">Pilih Kota Anda</option>')
                $.each(data, function(index, kotaObj){
                    $('#kota').append('<option value="'+kotaObj.id +'">'+ kotaObj.nama_kota +'</option>')
                })
            });
        });	

        // $('#kota').on('change', function(e){
        //     console.log(e);
        //     var id_kota = e.target.value;
        //     $.get('/json-wisata?kota_id=' + id_kota, function(data){
        //         $('#wisata').empty();
        //         $('#wisata').append('<option value="0" selected="true" disabled="true">Pilih WIsata Anda</option>')
        //         $.each(data, function(index, wisataObj){
        //             $('#wisata').append('<option value="'+wisataObj.id +'">'+ wisataObj.nama_wisata +'</option>')
        //         })
        //     });
        // });
    </script>

</html><?php /**PATH C:\xampp\htdocs\twido_v3\resources\views/rekom.blade.php ENDPATH**/ ?>