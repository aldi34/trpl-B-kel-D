<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class indexController extends Controller
{
    public function provinsi(){
        $provinsinya = \App\Provinsi::All();
        return view('beranda',['provinsinya' => $provinsinya]);
    }
    public function kota(Request $request){
        $id_provinsi = $request->provinsi_id;
        $kota = \App\Kota::where('provinsi_id','=', $id_provinsi)->get();
        return response()->json($kota);
    }
    
}
