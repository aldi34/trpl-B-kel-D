<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WisataController extends Controller
{
    public function provinsi(){
        $provinsinya = \App\Provinsi::All();
        return view('rekom',['provinsinya' => $provinsinya]);
    }
    public function kota(Request $request){
        $id_provinsi = $request->provinsi_id;
        $kota = \App\Kota::where('provinsi_id','=', $id_provinsi)->get();
        return response()->json($kota);
    }
    public function cari(Request $request){
        $kotaPencarian = \App\Kota::where('id','=',$request->kota)->first();
        $provinsiPencarian = \App\Provinsi::where('id','=',$request->provinsi)->first();

        $hasilcari = \App\Destinasi::select('*')
            ->where('provinsi_id','=',$request->provinsi)
            ->where('kota_id','=',$request->kota)
            ->where('tipe_destinasi','=',$request->jenis)
            ->get();
        return view('hasilcari',['hasilcari' => $hasilcari, 'kotaPencarian' => $kotaPencarian, 'provinsiPencarian' => $provinsiPencarian]);
    }
    // public function wisata(Request $request){
    //     $id_kota = $request->kota_id;
    //     $wisata = \App\Wisata::where('kota_id','=', $id_kota)->get();
    //     return response()->json($wisata);
    // }
}
