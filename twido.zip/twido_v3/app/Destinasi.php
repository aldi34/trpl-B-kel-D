<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Destinasi extends Model
{
    protected $table = 'destinasi';

    public function getAvatar()
    {
    	if(!$this->gambar){
    		return asset('fotoDestinasi/default.jpg');
    	}
    	return asset('fotoDestinasi/'.$this->gambar);
    }
}
